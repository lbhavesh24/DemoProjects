package com.example.billeasydemo.services

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class ApiClient {

    private var retrofit: Retrofit? = null

    val api: Api
        get() {

            val baseUrl = "https://api.themoviedb.org/3/"

            if (retrofit == null) {
                retrofit = Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(okClient())
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
            }

            return retrofit!!.create(Api::class.java!!)
        }

    private fun okClient(): OkHttpClient {

        val httpClient = OkHttpClient.Builder()
        httpClient.addInterceptor { chain ->
            val original = chain.request()
            var url = original.url().toString()
            url = url.replace("%3F", "?")
            url = url.replace("%3D", "=")

            // Request customization: add request headers
            val requestBuilder = original.newBuilder()

                .url(url)
            //.header("Authorization", "auth-value"); // <-- this is the important line

            val request = requestBuilder.build()
            chain.proceed(request)
        }

        return httpClient.build()
    }
}