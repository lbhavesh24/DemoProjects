package com.example.billeasydemo.view

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.billeasydemo.R
import com.example.billeasydemo.adapters.MoviesAdapter
import com.example.billeasydemo.helper.Utils
import com.example.billeasydemo.model.ResultsItem
import com.example.billeasydemo.presenter.MoviesListPresenter
import io.realm.Realm
import java.util.*


class MainActivity : AppCompatActivity(),
    MainView {
    private var presenter: MoviesListPresenter?= null
    private var moviesList: List<ResultsItem> ?=null
    private var realm: Realm? = null
    private lateinit var moviesRecyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        moviesRecyclerView = findViewById(R.id.movies_recyclerView)
        moviesRecyclerView.layoutManager = GridLayoutManager(this, 2)
        moviesRecyclerView.itemAnimator = DefaultItemAnimator()


        /*if (Realm.getDefaultConfiguration() != null && Utils.isNetworkOnline(this)) {
            Realm.deleteRealm(Realm.getDefaultConfiguration()!!)
        }*/

        realm = Realm.getDefaultInstance()

        moviesList = ArrayList()

        if (Utils.isNetworkOnline(this)) {
            presenter =
                MoviesListPresenter(this)
            presenter!!.getPopularMovies()
        } else {
            val movieListItems = realm!!.where<ResultsItem>(
                ResultsItem::class.java).findAll()
            val adapter = MoviesAdapter(this,movieListItems)
            moviesRecyclerView.adapter = adapter
        }

    }

    override fun onMoviesFetchedSuccess(moviesList: List<ResultsItem>) {
        val adapter = MoviesAdapter(this,moviesList)
        moviesRecyclerView.adapter = adapter
    }

    override fun onMoviesFetchError(error: String) {
        Toast.makeText(this, error, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        realm!!.close()
        super.onDestroy()
    }


}
