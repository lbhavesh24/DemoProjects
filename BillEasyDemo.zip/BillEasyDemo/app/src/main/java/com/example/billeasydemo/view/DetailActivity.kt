package com.example.billeasydemo.view

import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.bumptech.glide.Glide
import com.example.billeasydemo.R
import com.example.billeasydemo.model.MoviesListItem
import com.google.android.material.appbar.AppBarLayout
import com.google.android.material.appbar.AppBarLayout.OnOffsetChangedListener
import com.google.android.material.appbar.CollapsingToolbarLayout

class DetailActivity : AppCompatActivity() {
    private var nameOfMovie: TextView? = null
    private var plotSynopsis: TextView? = null
    private var userRating: TextView? = null
    private var releaseDate: TextView? = null
    private var imageView: ImageView? = null
    private lateinit var movie: MoviesListItem
    private var thumbnail: String? = null
    private var movieName: String? = null
    private var synopsis: String? = null
    private var rating: String? = null
    private var dateOfRelease: String? = null
    private var movie_id = 0

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        val toolbar =
            findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        initCollapsingToolbar()
        imageView =
            findViewById<View>(R.id.thumbnail_image_header) as ImageView
        nameOfMovie = findViewById<View>(R.id.title) as TextView
        plotSynopsis = findViewById<View>(R.id.plotsynopsis) as TextView
        userRating = findViewById<View>(R.id.userrating) as TextView
        releaseDate = findViewById<View>(R.id.releasedate) as TextView
        val intentThatStartedThisActivity = intent
        if (intentThatStartedThisActivity.hasExtra("movies")) {
            movie = intent.getParcelableExtra("movies")
            thumbnail = movie.posterPath
            movieName = movie.originalTitle
            synopsis = movie.overview
            rating = java.lang.Double.toString(movie.voteAverage)
            dateOfRelease = movie.releaseDate
            movie_id = movie.id
            val poster = "https://image.tmdb.org/t/p/w500$thumbnail"
            Glide.with(this)
                .load(poster)
                .placeholder(R.drawable.load)
                .into(imageView!!)
            nameOfMovie!!.text = movieName
            plotSynopsis!!.text = synopsis
            userRating!!.text = rating
            releaseDate!!.text = dateOfRelease
        } else {
            Toast.makeText(this, "No API Data", Toast.LENGTH_SHORT).show()
        }
    }

    private fun initCollapsingToolbar() {
        val collapsingToolbarLayout =
            findViewById<View>(R.id.collapsing_toolbar) as CollapsingToolbarLayout
        collapsingToolbarLayout.title = " "
        val appBarLayout =
            findViewById<View>(R.id.appbar) as AppBarLayout
        appBarLayout.setExpanded(true)
        appBarLayout.addOnOffsetChangedListener(object : OnOffsetChangedListener {
            var isShow = false
            var scrollRange = -1
            override fun onOffsetChanged(
                appBarLayout: AppBarLayout,
                verticalOffset: Int
            ) {
                if (scrollRange == -1) {
                    scrollRange = appBarLayout.totalScrollRange
                }
                if (scrollRange + verticalOffset == 0) {
                    collapsingToolbarLayout.title = getString(R.string.movie_details)
                    isShow = true
                } else if (isShow) {
                    collapsingToolbarLayout.title = " "
                    isShow = false
                }
            }
        })
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return super.onSupportNavigateUp()
    }
}