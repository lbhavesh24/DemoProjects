package com.example.billeasydemo.adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.billeasydemo.view.DetailActivity
import com.example.billeasydemo.model.MoviesListItem
import com.example.billeasydemo.R
import com.example.billeasydemo.model.ResultsItem
import com.example.billeasydemo.adapters.MoviesAdapter.MyViewHolder

class MoviesAdapter(private val mContext: Context, private val movieList: List<ResultsItem>) : RecyclerView.Adapter<MyViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): MyViewHolder {
        val view = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.movie_card, viewGroup, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: MyViewHolder, i: Int) {
        viewHolder.title.text = movieList[i].originalTitle
        val vote = java.lang.Double.toString(movieList[i].voteAverage)
        viewHolder.userrating.text = vote
        val poster =
            "https://image.tmdb.org/t/p/w500" + movieList[i].posterPath
        Glide.with(mContext)
            .load(poster)
            .placeholder(R.drawable.load)
            .into(viewHolder.thumbnail)
    }

    override fun getItemCount(): Int {
        return movieList.size
    }

    inner class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var title: TextView
        var userrating: TextView
        var thumbnail: ImageView

        init {
            title = view.findViewById<View>(R.id.title) as TextView
            userrating = view.findViewById<View>(R.id.userrating) as TextView
            thumbnail =
                view.findViewById<View>(R.id.thumbnail) as ImageView
            view.setOnClickListener { v ->
                val pos = adapterPosition
                if (pos != RecyclerView.NO_POSITION) {
                    val clickedDataItem = movieList[pos]
                    val intent = Intent(mContext, DetailActivity::class.java)
                    intent.putExtra("movies", adaptFromDTO(clickedDataItem))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    mContext.startActivity(intent)
                }
            }
        }
    }

    fun adaptFromDTO(dto: ResultsItem): MoviesListItem {
        val listItem = MoviesListItem()
        listItem.posterPath = dto.posterPath
        listItem.originalTitle = dto.originalTitle
        listItem.overview = dto.overview
        listItem.voteAverage = dto.voteAverage
        listItem.releaseDate = dto.releaseDate
        listItem.id = dto.id
        return listItem
    }

}