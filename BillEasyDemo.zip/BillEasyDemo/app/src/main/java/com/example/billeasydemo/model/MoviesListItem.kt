package com.example.billeasydemo.model

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

class MoviesListItem : Parcelable {
    @SerializedName("overview")
    var overview: String? = null

    @SerializedName("original_language")
    var originalLanguage: String? = null

    @SerializedName("original_title")
    var originalTitle: String? = null

    @SerializedName("video")
    var isVideo = false

    @SerializedName("title")
    var title: String? = null

    @SerializedName("poster_path")
    var posterPath: String? = null

    @SerializedName("backdrop_path")
    var backdropPath: String? = null

    @SerializedName("release_date")
    var releaseDate: String? = null

    @SerializedName("popularity")
    var popularity = 0.0

    @SerializedName("vote_average")
    var voteAverage = 0.0

    @SerializedName("id")
    var id = 0

    @SerializedName("adult")
    var isAdult = false

    @SerializedName("vote_count")
    var voteCount = 0

    constructor() {}

    protected constructor(`in`: Parcel) {
        overview = `in`.readString()
        originalLanguage = `in`.readString()
        originalTitle = `in`.readString()
        isVideo = `in`.readByte().toInt() != 0
        title = `in`.readString()
        posterPath = `in`.readString()
        backdropPath = `in`.readString()
        releaseDate = `in`.readString()
        popularity = `in`.readDouble()
        voteAverage = `in`.readDouble()
        id = `in`.readInt()
        isAdult = `in`.readByte().toInt() != 0
        voteCount = `in`.readInt()
    }

    override fun describeContents(): Int {
        return 0
    }

    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(overview)
        dest.writeString(originalLanguage)
        dest.writeString(originalTitle)
        dest.writeByte((if (isVideo) 1 else 0).toByte())
        dest.writeString(title)
        dest.writeString(posterPath)
        dest.writeString(backdropPath)
        dest.writeString(releaseDate)
        dest.writeDouble(popularity)
        dest.writeDouble(voteAverage)
        dest.writeInt(id)
        dest.writeByte((if (isAdult) 1 else 0).toByte())
        dest.writeInt(voteCount)
    }

    companion object CREATOR : Parcelable.Creator<MoviesListItem> {
        override fun createFromParcel(parcel: Parcel): MoviesListItem {
            return MoviesListItem(parcel)
        }

        override fun newArray(size: Int): Array<MoviesListItem?> {
            return arrayOfNulls(size)
        }
    }
}