package com.example.billeasydemo.view

import com.example.billeasydemo.model.ResultsItem

interface MainView {

    fun onMoviesFetchedSuccess(moviesList:List<ResultsItem>)
    fun onMoviesFetchError(error:String)
}