package com.example.billeasydemo.presenter

import com.example.billeasydemo.services.ApiClient
import com.example.billeasydemo.view.MainView
import com.example.billeasydemo.model.MovieResponse
import com.example.billeasydemo.model.ResultsItem
import io.realm.Realm
import io.realm.RealmList
import org.json.JSONException
import org.json.JSONObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException
import java.util.ArrayList

class MoviesListPresenter(private val mainView: MainView) {
    private var apiClient: ApiClient?= null
    private var moviesList:MutableList<ResultsItem> ?= null

    init {
        if (this.apiClient == null) {
            apiClient = ApiClient()
        }
    }

    fun getPopularMovies() {
        apiClient!!
            .api
            .getPopularMovies("1f9ab350a2073a4c18b0de1a2315f59b")
            ?.enqueue(object :Callback<MovieResponse?>{
                override fun onResponse(call: Call<MovieResponse?>, response: Response<MovieResponse?>) {
                    if (response.code() == 200){
                         var realm = Realm.getDefaultInstance()
                        moviesList = ArrayList()

                        moviesList!!.addAll(response.body()!!.results!!)

                        realm.executeTransaction {
                            val list = RealmList<ResultsItem>()
                            list.addAll(moviesList as ArrayList<ResultsItem>)
                            realm.insertOrUpdate(list)
                        }

                        val movieListItems = realm!!.where(ResultsItem::class.java).findAll()
                        mainView.onMoviesFetchedSuccess(movieListItems)
                    }else {
                        try {
                            val errorObject = JSONObject(response.errorBody()!!.string())
                            if (errorObject.has("message")) {
                                val errorMsg = errorObject.getString("message")
                                mainView.onMoviesFetchError(errorMsg)
                            }
                        } catch (e: JSONException) {
                            e.printStackTrace()
                        } catch (e: IOException) {
                            e.printStackTrace()
                        }

                    }
                }

                override fun onFailure(call: Call<MovieResponse?>, t: Throwable) {
                    mainView.onMoviesFetchError(t.toString())
                }

            })
    }

}
