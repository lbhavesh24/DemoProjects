package com.example.billeasydemo.model

import com.google.gson.annotations.SerializedName
import io.realm.RealmObject

open class ResultsItem : RealmObject() {
    @SerializedName("overview")
    var overview: String? = null

    @SerializedName("original_language")
    var originalLanguage: String? = null

    @SerializedName("original_title")
    var originalTitle: String? = null

    @SerializedName("video")
    var isVideo = false

    @SerializedName("title")
    var title: String? = null

    @SerializedName("poster_path")
    var posterPath: String? = null

    @SerializedName("backdrop_path")
    var backdropPath: String? = null

    @SerializedName("release_date")
    var releaseDate: String? = null

    @SerializedName("popularity")
    var popularity = 0.0

    @SerializedName("vote_average")
    var voteAverage = 0.0

    @SerializedName("id")
    var id = 0

    @SerializedName("adult")
    var isAdult = false

    @SerializedName("vote_count")
    var voteCount = 0

    override fun toString(): String {
        return "ResultsItem{" +
                "overview = '" + overview + '\'' +
                ",original_language = '" + originalLanguage + '\'' +
                ",original_title = '" + originalTitle + '\'' +
                ",video = '" + isVideo + '\'' +
                ",title = '" + title + '\'' +
                ",poster_path = '" + posterPath + '\'' +
                ",backdrop_path = '" + backdropPath + '\'' +
                ",release_date = '" + releaseDate + '\'' +
                ",popularity = '" + popularity + '\'' +
                ",vote_average = '" + voteAverage + '\'' +
                ",id = '" + id + '\'' +
                ",adult = '" + isAdult + '\'' +
                ",vote_count = '" + voteCount + '\'' +
                "}"
    }
}