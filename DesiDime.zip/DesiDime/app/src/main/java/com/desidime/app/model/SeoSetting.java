package com.desidime.app.model;

import com.google.gson.annotations.SerializedName;

public class SeoSetting{

	@SerializedName("web_url")
	private String webUrl;

	@SerializedName("description")
	private String description;

	@SerializedName("title")
	private String title;

	public void setWebUrl(String webUrl){
		this.webUrl = webUrl;
	}

	public String getWebUrl(){
		return webUrl;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return description;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return title;
	}

	@Override
 	public String toString(){
		return 
			"SeoSetting{" + 
			"web_url = '" + webUrl + '\'' + 
			",description = '" + description + '\'' + 
			",title = '" + title + '\'' + 
			"}";
		}
}