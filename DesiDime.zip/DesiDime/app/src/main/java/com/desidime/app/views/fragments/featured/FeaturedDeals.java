package com.desidime.app.views.fragments.featured;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.desidime.app.R;
import com.desidime.app.views.adapters.featuredDealsListAdapter;
import com.desidime.app.app.DesiDimeApp;
import com.desidime.app.helper.Constant;
import com.desidime.app.manager.PreferenceManager;
import com.desidime.app.model.DataItem;
import com.desidime.app.presenter.featuredDealsPresenter;

import java.util.ArrayList;
import java.util.List;

public class FeaturedDeals extends Fragment implements featuredDealsView, SwipeRefreshLayout.OnRefreshListener, com.desidime.app.views.adapters.featuredDealsListAdapter.ApiCallInterface {
    private AppCompatActivity context;
    private RecyclerView featuredDeals_rv;
    private featuredDealsListAdapter featuredDealsListAdapter;
    private featuredDealsPresenter featuredDealsPresenter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private List<DataItem> featuredDealsList = new ArrayList<>();

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = (AppCompatActivity) context;
        featuredDealsPresenter = new featuredDealsPresenter(context,this);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_featured_deals,container,false);
        initViews(view);
        return view;
    }

    @Override
    public void onSuccess(List<DataItem> dealsList) {
        swipeRefreshLayout.setRefreshing(false);

        if(featuredDealsListAdapter != null){
            if(PreferenceManager.getString(Constant.IS_PAGINATION_PROCESSING).equals("true")) {
                PreferenceManager.setString(Constant.IS_PAGINATION_PROCESSING, "false");

                featuredDealsList.addAll(dealsList);
                featuredDealsListAdapter.notifyDataSetChanged();
            }else
            {
                featuredDealsList.clear();
                featuredDealsList.addAll(dealsList);
                featuredDealsListAdapter.notifyDataSetChanged();
            }
        }
        else
        {
            featuredDealsList.clear();
            featuredDealsList.addAll(dealsList);
            DesiDimeApp.tempDealsList.clear();
            DesiDimeApp.tempDealsList.addAll(dealsList);
            featuredDealsListAdapter = new featuredDealsListAdapter(context,featuredDealsList,this);
            featuredDeals_rv.setAdapter(featuredDealsListAdapter);

        }

    }

    @Override
    public void onFailure(String msg) {
        swipeRefreshLayout.setRefreshing(false);
    }

    private void initViews(View view){

        featuredDeals_rv = view.findViewById(R.id.featured_deals_recyler);
        featuredDeals_rv.setLayoutManager(new LinearLayoutManager(context));
        swipeRefreshLayout = view.findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setOnRefreshListener(this);

        featuredDealsPresenter.viewFeaturedDeals("1");
    }

    @Override
    public void onRefresh() {
        featuredDealsPresenter.viewFeaturedDeals("1");
    }

    @Override
    public void callDealsPaginationApi(int pageNo) {
        PreferenceManager.setString(Constant.IS_PAGINATION_PROCESSING,"true");
        featuredDealsPresenter.viewFeaturedDeals(pageNo+"");
    }
}
