package com.desidime.app.presenter;

import android.content.Context;

import com.desidime.app.model.DealsListResponse;
import com.desidime.app.views.fragments.popular.popularDealsView;
import com.desidime.app.services.ApiClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class popularDealsPresenter {

    private ApiClient apiClient;
    private popularDealsView popularDealsView;


    public popularDealsPresenter(Context context, popularDealsView popularDealsView) {
        this.popularDealsView = popularDealsView;
        if (this.apiClient == null){
            this.apiClient = new ApiClient();
        }
    }


    public void viewPopularDeals(String pageNo) {


        apiClient
                .getApi()
                .getPopularDeals("10",pageNo)
                .enqueue(new Callback<DealsListResponse>() {
                    @Override
                    public void onResponse(Call<DealsListResponse> call, Response<DealsListResponse> response) {
                        if (response.isSuccessful() && response.body()!=null){
                            popularDealsView.onSuccess(response.body().getDeals().getData());
                        }

                    }

                    @Override
                    public void onFailure(Call<DealsListResponse> call, Throwable t) {
                        popularDealsView.onFailure(t.toString());
                    }
                });
    }

}
