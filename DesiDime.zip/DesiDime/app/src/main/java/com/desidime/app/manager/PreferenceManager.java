package com.desidime.app.manager;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;


public class PreferenceManager {

    private static SharedPreferences sharedPrefs;
    private static SharedPreferences.Editor preferenceEditor;
    private static Context context;

    public static void createSharedPreferences(final Context context) {

        PreferenceManager.context = context;
        sharedPrefs = android.preference.PreferenceManager.getDefaultSharedPreferences(PreferenceManager.context);
        preferenceEditor = sharedPrefs.edit();
    }

    public static void clearPreference() {
        preferenceEditor = sharedPrefs.edit();
        preferenceEditor.clear();
        preferenceEditor.commit();

    }

    public static void setString(String key, String str) {
        preferenceEditor.putString(key, TextUtils.isEmpty(str) ? "" : str);
        preferenceEditor.commit();
    }

    public static String getString(String key) {
        return sharedPrefs.getString(key, "");
    }
}
