package com.desidime.app.views.fragments.topdeals;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.desidime.app.R;
import com.desidime.app.views.adapters.topDealsListAdapter;
import com.desidime.app.app.DesiDimeApp;
import com.desidime.app.helper.Constant;
import com.desidime.app.manager.PreferenceManager;
import com.desidime.app.model.DataItem;
import com.desidime.app.presenter.topDealsPresenter;

import java.util.ArrayList;
import java.util.List;

public class TopDeals extends Fragment implements topDealsView, topDealsListAdapter.ApiCallInterface, SwipeRefreshLayout.OnRefreshListener {
    private AppCompatActivity context;
    private RecyclerView topDeals_rv;
    private topDealsPresenter topDealsPresenter;
    private topDealsListAdapter adapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private List<DataItem> topdealsList = new ArrayList<>();

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        this.context = (AppCompatActivity) context;
        topDealsPresenter = new topDealsPresenter(context,this);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_top_deals,container,false);
        initViews(view);
        return view;
    }

    @Override
    public void onSuccess(List<DataItem> dealsList) {
        swipeRefreshLayout.setRefreshing(false);

        if(adapter != null){
            if(PreferenceManager.getString(Constant.IS_PAGINATION_PROCESSING).equals("true")) {
                PreferenceManager.setString(Constant.IS_PAGINATION_PROCESSING, "false");

                topdealsList.addAll(dealsList);
                adapter.notifyDataSetChanged();
            }else
            {
                topdealsList.clear();
                topdealsList.addAll(dealsList);
                adapter.notifyDataSetChanged();
            }
        }
        else
        {
            topdealsList.clear();
            topdealsList.addAll(dealsList);
            DesiDimeApp.tempDealsList.clear();
            DesiDimeApp.tempDealsList.addAll(dealsList);
            adapter = new topDealsListAdapter(context,topdealsList,this);
            topDeals_rv.setAdapter(adapter);

        }

    }

    @Override
    public void onFailure(String msg) {
        swipeRefreshLayout.setRefreshing(false);

    }

    private void initViews(View view){

        topDeals_rv = view.findViewById(R.id.top_deals_recyler);
        topDeals_rv.setLayoutManager(new LinearLayoutManager(context));
        swipeRefreshLayout = view.findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setOnRefreshListener(this);

        topDealsPresenter.viewTopDeals("1");
    }

    @Override
    public void callDealsPaginationApi(int pageNo) {
        PreferenceManager.setString(Constant.IS_PAGINATION_PROCESSING,"true");
        topDealsPresenter.viewTopDeals(pageNo+"");
    }

    @Override
    public void onRefresh() {
        topDealsPresenter.viewTopDeals("1");
    }
}
