package com.desidime.app.app;

import android.app.Application;

import com.desidime.app.manager.PreferenceManager;
import com.desidime.app.model.DataItem;

import java.util.ArrayList;
import java.util.List;

public class DesiDimeApp extends Application {
    public static List<DataItem> tempDealsList;

    @Override
    public void onCreate() {
        super.onCreate();
        PreferenceManager.createSharedPreferences(this);
        tempDealsList = new ArrayList<>();


    }
}
