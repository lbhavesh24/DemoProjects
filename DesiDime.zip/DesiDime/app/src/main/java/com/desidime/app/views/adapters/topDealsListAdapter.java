package com.desidime.app.views.adapters;

import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.desidime.app.R;
import com.desidime.app.helper.Utils;
import com.desidime.app.model.DataItem;

import java.text.DecimalFormat;
import java.util.List;

public class topDealsListAdapter extends RecyclerView.Adapter<topDealsListAdapter.ViewHolder> {
    private List<DataItem> dataList;
    private Context context;
    private ApiCallInterface apiCallInterface;
    private int pageNo = 1;
    private double currentPrice,originalPrice;
    private String offPercentage;

    public topDealsListAdapter(Context context, List<DataItem> dataList,ApiCallInterface apiCallInterface) {
        this.dataList = dataList;
        this.context = context;
        this.apiCallInterface = apiCallInterface;
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        ImageView dealImage;
        TextView dealName, dealDate ,likes_count,comments_count,current_price,original_price,off_percent;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            dealImage = itemView.findViewById(R.id.deal_image);
            dealName = itemView.findViewById(R.id.deal_name);
            dealDate = itemView.findViewById(R.id.date);
            likes_count = itemView.findViewById(R.id.likes_count);
            comments_count = itemView.findViewById(R.id.comments_count);
            current_price = itemView.findViewById(R.id.current_price);
            original_price = itemView.findViewById(R.id.original_price);
            off_percent = itemView.findViewById(R.id.off_percent);

        }
    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.deals_list_item,viewGroup,false);
        return new ViewHolder(view);
    }


    @SuppressWarnings("deprecation")
    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        Glide.with(context).load(dataList.get(holder.getAdapterPosition()).getImage()).into(holder.dealImage);
        holder.dealName.setText(dataList.get(holder.getAdapterPosition()).getTitle());
        holder.likes_count.setText(dataList.get(holder.getAdapterPosition()).getScore()+"");
        holder.comments_count.setText(dataList.get(holder.getAdapterPosition()).getCommentsCount()+"");

        holder.dealDate.setText(Utils.getDate(dataList.get(holder.getAdapterPosition()).getCreatedAt(),"dd MMM yyyy"));

        currentPrice = dataList.get(holder.getAdapterPosition()).getCurrentPrice();
        originalPrice = dataList.get(holder.getAdapterPosition()).getOriginalPrice();
        offPercentage = dataList.get(holder.getAdapterPosition()).getOffPercent();

        if (currentPrice>0){
            holder.current_price.setText("Rs " + new DecimalFormat("#").format(currentPrice));
        }

        if (originalPrice>0){
            holder.original_price.setText("Rs "+ new DecimalFormat("#").format(originalPrice));
            holder.original_price.setPaintFlags(holder.original_price.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }

        if (!offPercentage.isEmpty() && !offPercentage.equals("0")){
            holder.off_percent.setText(offPercentage+"% Off");
        }

        if (dataList.size()>=10) {
            if (position >= (dataList.size() - 1)) {
                apiCallInterface.callDealsPaginationApi(++pageNo);
            }
        }

    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    public interface ApiCallInterface {

        void callDealsPaginationApi(int pageNo);

    }
}
