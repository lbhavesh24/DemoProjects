package com.desidime.app.views.fragments.featured;

import com.desidime.app.model.DataItem;

import java.util.List;

public interface featuredDealsView {

    void onSuccess(List<DataItem> dealsList);
    void onFailure(String msg);

}
