package com.desidime.app.services;

import com.desidime.app.model.DealsListResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;

public interface Api {


    @Headers("X-Desidime-Client: 68045fd226ab32029c98bf4533bfa98b3c50423094d292d70ca2702e61a9679b")
    @GET("deals/top.json")
    Call<DealsListResponse> getTopDeals(@Query(value ="per_page",encoded = true) String itemCount, @Query(value = "page",encoded = true) String pageNo);

    @Headers("X-Desidime-Client: 68045fd226ab32029c98bf4533bfa98b3c50423094d292d70ca2702e61a9679b")
    @GET("deals/popular.json")
    Call<DealsListResponse> getPopularDeals(@Query(value ="per_page",encoded = true) String itemCount, @Query(value = "page",encoded = true) String pageNo);

    @Headers("X-Desidime-Client: 68045fd226ab32029c98bf4533bfa98b3c50423094d292d70ca2702e61a9679b")
    @GET("deals/featured.json")
    Call<DealsListResponse> getFeaturedDeals(@Query(value ="per_page",encoded = true) String itemCount, @Query(value = "page",encoded = true) String pageNo);


}