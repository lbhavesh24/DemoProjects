package com.desidime.app.model;

import com.google.gson.annotations.SerializedName;

public class Merchant{

	@SerializedName("image")
	private String image;

	@SerializedName("name")
	private String name;

	@SerializedName("recommendation_flag")
	private boolean recommendationFlag;

	@SerializedName("recommendation")
	private int recommendation;

	@SerializedName("average_rating")
	private String averageRating;

	@SerializedName("id")
	private int id;

	@SerializedName("permalink")
	private String permalink;

	public void setImage(String image){
		this.image = image;
	}

	public String getImage(){
		return image;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setRecommendationFlag(boolean recommendationFlag){
		this.recommendationFlag = recommendationFlag;
	}

	public boolean isRecommendationFlag(){
		return recommendationFlag;
	}

	public void setRecommendation(int recommendation){
		this.recommendation = recommendation;
	}

	public int getRecommendation(){
		return recommendation;
	}

	public void setAverageRating(String averageRating){
		this.averageRating = averageRating;
	}

	public String getAverageRating(){
		return averageRating;
	}

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	public void setPermalink(String permalink){
		this.permalink = permalink;
	}

	public String getPermalink(){
		return permalink;
	}

	@Override
 	public String toString(){
		return 
			"Merchant{" + 
			"image = '" + image + '\'' + 
			",name = '" + name + '\'' + 
			",recommendation_flag = '" + recommendationFlag + '\'' + 
			",recommendation = '" + recommendation + '\'' + 
			",average_rating = '" + averageRating + '\'' + 
			",id = '" + id + '\'' + 
			",permalink = '" + permalink + '\'' + 
			"}";
		}
}