package com.desidime.app.model;

import com.google.gson.annotations.SerializedName;


public class DealsListResponse {

	@SerializedName("deals")
	private Deals deals;

	@SerializedName("seo_setting")
	private SeoSetting seoSetting;

	public void setDeals(Deals deals){
		this.deals = deals;
	}

	public Deals getDeals(){
		return deals;
	}

	public void setSeoSetting(SeoSetting seoSetting){
		this.seoSetting = seoSetting;
	}

	public SeoSetting getSeoSetting(){
		return seoSetting;
	}

	@Override
 	public String toString(){
		return 
			"DealsListResponse{" +
			"deals = '" + deals + '\'' + 
			",seo_setting = '" + seoSetting + '\'' + 
			"}";
		}
}