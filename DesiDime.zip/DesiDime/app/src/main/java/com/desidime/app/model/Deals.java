package com.desidime.app.model;

import java.util.List;

import com.desidime.app.model.DataItem;
import com.google.gson.annotations.SerializedName;

public class Deals{

	@SerializedName("data")
	private List<DataItem> data;

	@SerializedName("total_count")
	private int totalCount;

	public void setData(List<DataItem> data){
		this.data = data;
	}

	public List<DataItem> getData(){
		return data;
	}

	public void setTotalCount(int totalCount){
		this.totalCount = totalCount;
	}

	public int getTotalCount(){
		return totalCount;
	}

	@Override
 	public String toString(){
		return 
			"Deals{" + 
			"data = '" + data + '\'' + 
			",total_count = '" + totalCount + '\'' + 
			"}";
		}
}