package com.desidime.app.presenter;

import android.content.Context;

import com.desidime.app.model.DealsListResponse;
import com.desidime.app.views.fragments.featured.featuredDealsView;
import com.desidime.app.services.ApiClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class featuredDealsPresenter {

    private ApiClient apiClient;
    private featuredDealsView featuredDealsView;


    public featuredDealsPresenter(Context context, featuredDealsView featuredDealsView) {
        this.featuredDealsView = featuredDealsView;
        if (this.apiClient == null){
            this.apiClient = new ApiClient();
        }
    }


    public void viewFeaturedDeals(String pageNo) {


        apiClient
                .getApi()
                .getFeaturedDeals("10",pageNo)
                .enqueue(new Callback<DealsListResponse>() {
                    @Override
                    public void onResponse(Call<DealsListResponse> call, Response<DealsListResponse> response) {
                        if (response.isSuccessful() && response.body()!=null){
                            featuredDealsView.onSuccess(response.body().getDeals().getData());
                        }

                    }

                    @Override
                    public void onFailure(Call<DealsListResponse> call, Throwable t) {
                        featuredDealsView.onFailure(t.toString());
                    }
                });
    }

}
