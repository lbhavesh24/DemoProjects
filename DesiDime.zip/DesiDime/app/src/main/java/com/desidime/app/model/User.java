package com.desidime.app.model;


import com.google.gson.annotations.SerializedName;

public class User{

	@SerializedName("fpd_count")
	private int fpdCount;

	@SerializedName("image")
	private String image;

	@SerializedName("karma")
	private int karma;

	@SerializedName("name")
	private String name;

	@SerializedName("rank")
	private String rank;

	@SerializedName("current_dimes")
	private int currentDimes;

	@SerializedName("id")
	private int id;

	public void setFpdCount(int fpdCount){
		this.fpdCount = fpdCount;
	}

	public int getFpdCount(){
		return fpdCount;
	}

	public void setImage(String image){
		this.image = image;
	}

	public String getImage(){
		return image;
	}

	public void setKarma(int karma){
		this.karma = karma;
	}

	public int getKarma(){
		return karma;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getName(){
		return name;
	}

	public void setRank(String rank){
		this.rank = rank;
	}

	public String getRank(){
		return rank;
	}

	public void setCurrentDimes(int currentDimes){
		this.currentDimes = currentDimes;
	}

	public int getCurrentDimes(){
		return currentDimes;
	}

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	@Override
 	public String toString(){
		return 
			"User{" + 
			"fpd_count = '" + fpdCount + '\'' + 
			",image = '" + image + '\'' + 
			",karma = '" + karma + '\'' + 
			",name = '" + name + '\'' + 
			",rank = '" + rank + '\'' + 
			",current_dimes = '" + currentDimes + '\'' + 
			",id = '" + id + '\'' + 
			"}";
		}
}