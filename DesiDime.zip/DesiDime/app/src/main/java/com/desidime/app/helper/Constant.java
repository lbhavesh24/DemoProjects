package com.desidime.app.helper;

import android.content.Context;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Constant {

    public static final String BASE_URL = "https://stagingapi.desidime.com/v3/";

    public static final String HOME = "Deals";
    public static final String IS_PAGINATION_PROCESSING = "pagination_api_call";
}
