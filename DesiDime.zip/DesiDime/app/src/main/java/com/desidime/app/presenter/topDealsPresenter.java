package com.desidime.app.presenter;

import android.content.Context;

import com.desidime.app.model.DealsListResponse;
import com.desidime.app.views.fragments.topdeals.topDealsView;
import com.desidime.app.services.ApiClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class topDealsPresenter {

    private ApiClient apiClient;
    private topDealsView dealsView;


    public topDealsPresenter(Context context, topDealsView dealsView) {
        this.dealsView = dealsView;
        if (this.apiClient == null){
            this.apiClient = new ApiClient();
        }
    }


    public void viewTopDeals(String pageNo) {


        apiClient
                .getApi()
                .getTopDeals("10",pageNo)
                .enqueue(new Callback<DealsListResponse>() {
                    @Override
                    public void onResponse(Call<DealsListResponse> call, Response<DealsListResponse> response) {
                        if (response.isSuccessful() && response.body()!=null){
                            dealsView.onSuccess(response.body().getDeals().getData());
                        }

                    }

                    @Override
                    public void onFailure(Call<DealsListResponse> call, Throwable t) {
                        dealsView.onFailure(t.toString());
                    }
                });
    }

}
