package com.desidime.app.model;


import com.google.gson.annotations.SerializedName;

public class DataItem{

	@SerializedName("original_price")
	private double originalPrice;

	@SerializedName("image")
	private String image;

	@SerializedName("all_posts_count")
	private int allPostsCount;

	@SerializedName("front_page_suggestions_count")
	private int frontPageSuggestionsCount;

	@SerializedName("created_at")
	private long createdAt;

	@SerializedName("description")
	private Object description;

	@SerializedName("merchant")
	private Merchant merchant;

	@SerializedName("title")
	private String title;

	@SerializedName("fpd_suggestted")
	private boolean fpdSuggestted;

	@SerializedName("fpd_flag")
	private boolean fpdFlag;

	@SerializedName("vote_value")
	private int voteValue;

	@SerializedName("score")
	private int score;

	@SerializedName("deal_url")
	private String dealUrl;

	@SerializedName("comments_count")
	private int commentsCount;

	@SerializedName("share_url")
	private String shareUrl;

	@SerializedName("id")
	private int id;

	@SerializedName("current_price")
	private double currentPrice;

	@SerializedName("state")
	private String state;

	@SerializedName("vote_down_reason")
	private VoteDownReason voteDownReason;

	@SerializedName("off_percent")
	private String offPercent;

	@SerializedName("vote_count")
	private int voteCount;

	@SerializedName("user")
	private User user;

	@SerializedName("view_count")
	private int viewCount;

	public void setOriginalPrice(double originalPrice){
		this.originalPrice = originalPrice;
	}

	public double getOriginalPrice(){
		return originalPrice;
	}

	public void setImage(String image){
		this.image = image;
	}

	public String getImage(){
		return image;
	}

	public void setAllPostsCount(int allPostsCount){
		this.allPostsCount = allPostsCount;
	}

	public int getAllPostsCount(){
		return allPostsCount;
	}

	public void setFrontPageSuggestionsCount(int frontPageSuggestionsCount){
		this.frontPageSuggestionsCount = frontPageSuggestionsCount;
	}

	public int getFrontPageSuggestionsCount(){
		return frontPageSuggestionsCount;
	}

	public void setCreatedAt(long createdAt){
		this.createdAt = createdAt;
	}

	public long getCreatedAt(){
		return createdAt;
	}

	public void setDescription(Object description){
		this.description = description;
	}

	public Object getDescription(){
		return description;
	}

	public void setMerchant(Merchant merchant){
		this.merchant = merchant;
	}

	public Merchant getMerchant(){
		return merchant;
	}

	public void setTitle(String title){
		this.title = title;
	}

	public String getTitle(){
		return title;
	}

	public void setFpdSuggestted(boolean fpdSuggestted){
		this.fpdSuggestted = fpdSuggestted;
	}

	public boolean isFpdSuggestted(){
		return fpdSuggestted;
	}

	public void setFpdFlag(boolean fpdFlag){
		this.fpdFlag = fpdFlag;
	}

	public boolean isFpdFlag(){
		return fpdFlag;
	}

	public void setVoteValue(int voteValue){
		this.voteValue = voteValue;
	}

	public int getVoteValue(){
		return voteValue;
	}

	public void setScore(int score){
		this.score = score;
	}

	public int getScore(){
		return score;
	}

	public void setDealUrl(String dealUrl){
		this.dealUrl = dealUrl;
	}

	public String getDealUrl(){
		return dealUrl;
	}

	public void setCommentsCount(int commentsCount){
		this.commentsCount = commentsCount;
	}

	public int getCommentsCount(){
		return commentsCount;
	}

	public void setShareUrl(String shareUrl){
		this.shareUrl = shareUrl;
	}

	public String getShareUrl(){
		return shareUrl;
	}

	public void setId(int id){
		this.id = id;
	}

	public int getId(){
		return id;
	}

	public void setCurrentPrice(double currentPrice){
		this.currentPrice = currentPrice;
	}

	public double getCurrentPrice(){
		return currentPrice;
	}

	public void setState(String state){
		this.state = state;
	}

	public String getState(){
		return state;
	}

	public void setVoteDownReason(VoteDownReason voteDownReason){
		this.voteDownReason = voteDownReason;
	}

	public VoteDownReason getVoteDownReason(){
		return voteDownReason;
	}

	public void setOffPercent(String offPercent){
		this.offPercent = offPercent;
	}

	public String getOffPercent(){
		return offPercent;
	}

	public void setVoteCount(int voteCount){
		this.voteCount = voteCount;
	}

	public int getVoteCount(){
		return voteCount;
	}

	public void setUser(User user){
		this.user = user;
	}

	public User getUser(){
		return user;
	}

	public void setViewCount(int viewCount){
		this.viewCount = viewCount;
	}

	public int getViewCount(){
		return viewCount;
	}

	@Override
 	public String toString(){
		return 
			"DataItem{" + 
			"original_price = '" + originalPrice + '\'' + 
			",image = '" + image + '\'' + 
			",all_posts_count = '" + allPostsCount + '\'' + 
			",front_page_suggestions_count = '" + frontPageSuggestionsCount + '\'' + 
			",created_at = '" + createdAt + '\'' + 
			",description = '" + description + '\'' + 
			",merchant = '" + merchant + '\'' + 
			",title = '" + title + '\'' + 
			",fpd_suggestted = '" + fpdSuggestted + '\'' + 
			",fpd_flag = '" + fpdFlag + '\'' + 
			",vote_value = '" + voteValue + '\'' + 
			",score = '" + score + '\'' + 
			",deal_url = '" + dealUrl + '\'' + 
			",comments_count = '" + commentsCount + '\'' + 
			",share_url = '" + shareUrl + '\'' + 
			",id = '" + id + '\'' + 
			",current_price = '" + currentPrice + '\'' + 
			",state = '" + state + '\'' + 
			",vote_down_reason = '" + voteDownReason + '\'' + 
			",off_percent = '" + offPercent + '\'' + 
			",vote_count = '" + voteCount + '\'' + 
			",user = '" + user + '\'' + 
			",view_count = '" + viewCount + '\'' + 
			"}";
		}
}