package com.desidime.app.views.fragments.popular;

import com.desidime.app.model.DataItem;

import java.util.List;

public interface popularDealsView {

    void onSuccess(List<DataItem> dealsList);
    void onFailure(String msg);

}
