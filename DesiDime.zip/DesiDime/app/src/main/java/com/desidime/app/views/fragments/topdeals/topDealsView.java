package com.desidime.app.views.fragments.topdeals;

import com.desidime.app.model.DataItem;

import java.util.List;

public interface topDealsView {

    void onSuccess(List<DataItem> dealsList);
    void onFailure(String msg);

}
