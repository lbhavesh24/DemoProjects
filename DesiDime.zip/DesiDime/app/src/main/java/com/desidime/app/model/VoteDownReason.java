package com.desidime.app.model;


import com.google.gson.annotations.SerializedName;

public class VoteDownReason{

	@SerializedName("Self Promotion")
	private int selfPromotion;

	@SerializedName("Repost")
	private int repost;

	@SerializedName("Referral link")
	private int referralLink;

	@SerializedName("Product not good/not worth the price")
	private int productNotGoodNotWorthThePrice;

	@SerializedName("Invalid/User Specific Coupon/Deal")
	private int invalidUserSpecificCouponDeal;

	@SerializedName("Other reasons")
	private int otherReasons;

	@SerializedName("Better price elsewhere")
	private int betterPriceElsewhere;

	public void setSelfPromotion(int selfPromotion){
		this.selfPromotion = selfPromotion;
	}

	public int getSelfPromotion(){
		return selfPromotion;
	}

	public void setRepost(int repost){
		this.repost = repost;
	}

	public int getRepost(){
		return repost;
	}

	public void setReferralLink(int referralLink){
		this.referralLink = referralLink;
	}

	public int getReferralLink(){
		return referralLink;
	}

	public void setProductNotGoodNotWorthThePrice(int productNotGoodNotWorthThePrice){
		this.productNotGoodNotWorthThePrice = productNotGoodNotWorthThePrice;
	}

	public int getProductNotGoodNotWorthThePrice(){
		return productNotGoodNotWorthThePrice;
	}

	public void setInvalidUserSpecificCouponDeal(int invalidUserSpecificCouponDeal){
		this.invalidUserSpecificCouponDeal = invalidUserSpecificCouponDeal;
	}

	public int getInvalidUserSpecificCouponDeal(){
		return invalidUserSpecificCouponDeal;
	}

	public void setOtherReasons(int otherReasons){
		this.otherReasons = otherReasons;
	}

	public int getOtherReasons(){
		return otherReasons;
	}

	public void setBetterPriceElsewhere(int betterPriceElsewhere){
		this.betterPriceElsewhere = betterPriceElsewhere;
	}

	public int getBetterPriceElsewhere(){
		return betterPriceElsewhere;
	}

	@Override
 	public String toString(){
		return 
			"VoteDownReason{" + 
			"self Promotion = '" + selfPromotion + '\'' + 
			",repost = '" + repost + '\'' + 
			",referral link = '" + referralLink + '\'' + 
			",product not good/not worth the price = '" + productNotGoodNotWorthThePrice + '\'' + 
			",invalid/User Specific Coupon/Deal = '" + invalidUserSpecificCouponDeal + '\'' + 
			",other reasons = '" + otherReasons + '\'' + 
			",better price elsewhere = '" + betterPriceElsewhere + '\'' + 
			"}";
		}
}